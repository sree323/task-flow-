# ✅ TaskFlow — Simple To-Do List Website

TaskFlow is a beginner-friendly, responsive to-do list web application built using **HTML, CSS, and vanilla JavaScript**. Tasks are saved in your browser using `localStorage`, so no server or database is required.

## Features

- ➕ Add tasks quickly
- ✅ Mark tasks as completed or active
- 🗑️ Delete individual tasks
- 🔎 Filter **All**, **Active**, and **Completed** tasks
- 🧹 Clear all completed tasks
- 💾 Automatically save tasks in your browser
- 📱 Responsive layout for mobile and desktop
- ♿ Keyboard-friendly buttons and accessible labels

## Technologies Used

- HTML5
- CSS3
- JavaScript (ES6+)
- Browser Local Storage API

## Project Structure

```text
TaskFlow-GitHub/
├── index.html     # Main web page
├── style.css      # Responsive styling
├── script.js      # Task functionality and persistence
├── README.md      # Project documentation
└── LICENSE        # MIT License
```

## Getting Started

1. Download or clone this repository:

   ```bash
   git clone https://github.com/YOUR_USERNAME/TaskFlow-GitHub.git
   ```

2. Open the folder.
3. Double-click `index.html` to run the website in a browser.
4. Add tasks and start organizing your day!

> No installation, build tools, dependencies, or API keys are needed.

## How It Works

The JavaScript file handles task creation, completion, removal, and filtering. The list is serialized as JSON into browser `localStorage` after each change. On refresh, the app restores tasks from the same browser and device.

**Note:** Local storage is browser-specific. Clearing site data may delete saved tasks. This app is designed for personal use and does not sync tasks between devices.

## Deploy to GitHub Pages

1. Create a **public** GitHub repository named `TaskFlow-GitHub`.
2. Upload the contents of this project (keep `index.html` in the repository root), or push using Git.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then save.
6. After deployment, visit `https://YOUR_USERNAME.github.io/TaskFlow-GitHub/`.

## Suggested Improvements

- Add due dates and priority labels
- Add task editing and a search bar
- Add dark/light mode preference
- Add optional cloud synchronization

## License

This project is released under the MIT License. See [LICENSE](LICENSE).
