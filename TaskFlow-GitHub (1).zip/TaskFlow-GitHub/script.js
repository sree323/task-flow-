'use strict';

const STORAGE_KEY = 'taskflow-tasks-v1';
const form = document.getElementById('task-form');
const input = document.getElementById('task-input');
const list = document.getElementById('task-list');
const emptyState = document.getElementById('empty-state');
const count = document.getElementById('task-count');
const clearButton = document.getElementById('clear-completed');
const filterButtons = Array.from(document.querySelectorAll('[data-filter]'));

function loadTasks() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    if (!Array.isArray(saved)) return [];
    return saved.filter(t => t && typeof t.id === 'string' && typeof t.text === 'string' && typeof t.completed === 'boolean').slice(0, 1000);
  } catch (_) {
    return [];
  }
}

let tasks = loadTasks();
let currentFilter = 'all';

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (_) {
    count.textContent = 'Storage unavailable; tasks may not be saved';
  }
}

function render() {
  list.replaceChildren();
  const visible = tasks.filter(t => currentFilter === 'all' || (currentFilter === 'completed' ? t.completed : !t.completed));
  for (const task of visible) {
    const item = document.createElement('li');
    if (task.completed) item.classList.add('completed');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'check';
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Mark ${task.text} as ${task.completed ? 'active' : 'completed'}`);
    checkbox.addEventListener('change', () => {
      task.completed = checkbox.checked;
      saveTasks();
      render();
    });
    const name = document.createElement('span');
    name.className = 'task-text';
    name.textContent = task.text;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'delete';
    remove.textContent = '×';
    remove.setAttribute('aria-label', `Delete ${task.text}`);
    remove.addEventListener('click', () => {
      tasks = tasks.filter(t => t.id !== task.id);
      saveTasks();
      render();
    });
    item.append(checkbox, name, remove);
    list.appendChild(item);
  }
  emptyState.hidden = visible.length !== 0;
  const remaining = tasks.filter(t => !t.completed).length;
  count.textContent = `${remaining} ${remaining === 1 ? 'task' : 'tasks'} left`;
  clearButton.disabled = !tasks.some(t => t.completed);
  clearButton.style.opacity = clearButton.disabled ? '.4' : '1';
  filterButtons.forEach(button => {
    const active = button.dataset.filter === currentFilter;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

form.addEventListener('submit', event => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  const id = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  tasks.unshift({ id, text, completed: false });
  saveTasks();
  input.value = '';
  input.focus();
  render();
});

filterButtons.forEach(button => button.addEventListener('click', () => {
  currentFilter = button.dataset.filter;
  render();
}));

clearButton.addEventListener('click', () => {
  tasks = tasks.filter(t => !t.completed);
  saveTasks();
  render();
});

render();
