const byId = (id) => document.getElementById(id);
let currentLocation = null;

byId("locationBtn").addEventListener("click", () => {
  const status = byId("locationStatus");
  if (!("geolocation" in navigator)) {
    status.textContent = "This browser does not support location access.";
    return;
  }
  status.textContent = "Requesting permission…";
  navigator.geolocation.getCurrentPosition(
    (position) => {
      currentLocation = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      };
      const coords = `${currentLocation.latitude.toFixed(5)}, ${currentLocation.longitude.toFixed(5)}`;
      byId("locationText").textContent = coords;
      status.textContent = "Location captured in this browser session.";
    },
    (error) => {
      const messages = {
        1: "Location permission was denied. You can still prepare an alert without it.",
        2: "Your location is currently unavailable.",
        3: "Location request timed out. Please try again."
      };
      status.textContent = messages[error.code] || "Unable to get location.";
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
  );
});

byId("prepareBtn").addEventListener("click", () => {
  const name = byId("personName").value.trim() || "Not provided";
  const contact = byId("contactName").value.trim() || "Trusted contact";
  const details = byId("details").value.trim() || "I may need assistance. Please contact me.";
  const phone = byId("phone").value.trim();
  const location = currentLocation
    ? `Location coordinates: ${currentLocation.latitude}, ${currentLocation.longitude}`
    : "Location: Not shared";
  const message = `EMERGENCY ALERT - LIFELINK DEMO\nName: ${name}\nFor: ${contact}\nDetails: ${details}\n${location}\n\nThis message was prepared using a student demo. Please verify the situation and contact local emergency services if needed.`;
  byId("messageOutput").value = message;
  byId("messagePanel").hidden = false;
  const smsBody = encodeURIComponent(message);
  byId("smsLink").href = phone ? `sms:${encodeURIComponent(phone)}?body=${smsBody}` : `sms:?body=${smsBody}`;
  byId("messagePanel").scrollIntoView({ behavior: "smooth", block: "start" });
});

byId("copyBtn").addEventListener("click", async () => {
  const text = byId("messageOutput").value;
  try {
    await navigator.clipboard.writeText(text);
    byId("copyStatus").textContent = "Message copied. Paste it into your preferred messaging app.";
  } catch {
    byId("messageOutput").select();
    byId("copyStatus").textContent = "Select and copy the message manually (Ctrl+C / Cmd+C).";
  }
});

byId("resetBtn").addEventListener("click", () => {
  byId("personName").value = "";
  byId("contactName").value = "";
  byId("phone").value = "";
  byId("details").value = "";
  byId("messagePanel").hidden = true;
  byId("locationStatus").textContent = "Location has not been requested.";
  byId("locationText").textContent = "No location available";
  currentLocation = null;
});
