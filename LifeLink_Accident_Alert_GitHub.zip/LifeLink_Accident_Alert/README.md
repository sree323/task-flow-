# LifeLink Accident Alert

**A front-end student prototype built with HTML, CSS and JavaScript.**

LifeLink demonstrates a simple emergency-alert workflow: enter basic details, optionally request browser location, prepare a message, review it, and copy it or open the device SMS app.

> **Important safety notice:** This is an educational prototype only. It does not detect accidents, contact emergency services, send messages automatically, or guarantee delivery. It is not a replacement for emergency services. In a real emergency, contact your local emergency number directly.

## Features

- Responsive layout for desktop and mobile
- Emergency contact and incident-detail form
- Optional browser geolocation (requires user permission)
- Prepared message preview
- Copy-to-clipboard action
- Opens the device SMS app with a prefilled message (user must review and send)
- No backend, API key, database, or paid service required

## Project structure

```text
LifeLink_Accident_Alert/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── demo-preview.svg
```

## Run locally

1. Download and extract the ZIP file.
2. Open the extracted `LifeLink_Accident_Alert` folder.
3. Double-click `index.html` to open it in a browser.
4. For location access, run it through a local development server (for example, VS Code + Live Server) or deploy it using HTTPS.
5. Enter sample details and select **Prepare emergency message**.

## Deploy with GitHub Pages

1. Sign in to GitHub and create a new **Public** repository named `lifelink-accident-alert`.
2. Extract this ZIP on your computer.
3. Open the repository and choose **Add file → Upload files**.
4. Upload `index.html`, `style.css`, `script.js`, `README.md`, and the `assets` folder contents. Upload the files inside the project folder, not an extra nested folder.
5. Commit the files to the `main` branch.
6. Open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Select branch `main` and folder `/ (root)`, then save.
9. Wait for GitHub Pages to publish the site. The Pages section will show the website URL.

## Test checklist

- [ ] Page opens without errors
- [ ] Form accepts a name and details
- [ ] Location permission flow displays a useful status
- [ ] Alert preview includes entered information
- [ ] Copy button works (may require HTTPS or localhost)
- [ ] SMS link opens a supported messaging app, where available
- [ ] Layout works on a mobile-sized screen

## Technology

- HTML5
- CSS3
- Vanilla JavaScript
- Browser Geolocation API
- Clipboard API
- `sms:` link scheme

## Limitations and future improvements

This demo has no server-side storage, authentication, automatic crash detection, live tracking, SMS gateway, or emergency-service integration. A production system would require careful privacy/security design, reliable backend infrastructure, consent management, tested integrations, and partnerships with relevant emergency-response providers.

## Author

**Created by: Sree Varsan**

Student project prototype.
